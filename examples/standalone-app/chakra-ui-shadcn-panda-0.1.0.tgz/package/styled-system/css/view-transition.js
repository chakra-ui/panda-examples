import { toHash } from '../helpers';

export const viewTransition = (options) => {
  const prefix = null
  const slots = ['group', 'imagePair', 'old', 'new']
  const filtered = {}
  if (options && typeof options === 'object') {
    for (const key of slots) {
      if (key in options) filtered[key] = options[key]
    }
  }
  const base = 'vt_' + toHash(stableStringify(filtered))
  return prefix ? prefix + '-' + base : base

  function stableStringify(value) {
    if (value === null) return 'null'
    const t = typeof value
    if (t === 'boolean') return value ? 'true' : 'false'
    if (t === 'number') return Number.isFinite(value) ? String(value) : 'null'
    if (t === 'string') return JSON.stringify(value)
    if (Array.isArray(value)) {
      let out = '['
      for (let i = 0; i < value.length; i++) {
        if (i) out += ','
        out += stableStringify(value[i])
      }
      return out + ']'
    }
    if (t === 'object') {
      const keys = Object.keys(value).sort()
      let out = '{'
      for (let i = 0; i < keys.length; i++) {
        if (i) out += ','
        const key = keys[i]
        out += JSON.stringify(key) + ':' + stableStringify(value[key])
      }
      return out + '}'
    }
    return 'null'
  }
}