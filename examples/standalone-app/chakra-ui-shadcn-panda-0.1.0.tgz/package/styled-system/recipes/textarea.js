import { createRecipe } from './runtime';

const textareaConfig = {"name":"textarea"}

export const textarea = /* @__PURE__ */ createRecipe(textareaConfig)