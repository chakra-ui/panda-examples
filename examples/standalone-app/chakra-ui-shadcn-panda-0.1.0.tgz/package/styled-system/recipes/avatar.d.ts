import type { ConditionalValue } from '../types/system';
import type { SlotRecipeRuntimeFn, RecipeVariantMap } from '../types/recipe';

export type AvatarVariant = {
  size?: "default" | "lg" | "sm"
}

export type AvatarVariantProps = {
  [K in keyof AvatarVariant]?: ConditionalValue<AvatarVariant[K]>
}

export type AvatarVariantMap = RecipeVariantMap<AvatarVariant>

export type AvatarSlot = "root" | "image" | "fallback"

export type AvatarRecipe = SlotRecipeRuntimeFn<AvatarSlot, AvatarVariantProps, AvatarVariantMap>

export declare const avatar: AvatarRecipe;