import type { ConditionalValue } from '../types/system';
import type { RecipeRuntimeFn, RecipeVariantMap } from '../types/recipe';

export type TextareaVariant = {}

export type TextareaVariantProps = {
  [K in keyof TextareaVariant]?: ConditionalValue<TextareaVariant[K]>
}

export type TextareaVariantMap = RecipeVariantMap<TextareaVariant>

export type TextareaRecipe = RecipeRuntimeFn<TextareaVariantProps, TextareaVariantMap>

export declare const textarea: TextareaRecipe;