import { createRecipe } from './runtime';

const labelConfig = {"name":"label"}

export const label = /* @__PURE__ */ createRecipe(labelConfig)