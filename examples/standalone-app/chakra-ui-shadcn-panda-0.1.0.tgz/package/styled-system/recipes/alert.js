import { createSlotRecipe } from './runtime';

const alertConfig = {"name":"alert","slots":["root","title","description"],"defaultVariants":{"variant":"default"},"variantMap":{"variant":["default","destructive"]}}

export const alert = /* @__PURE__ */ createSlotRecipe(alertConfig)