import { createRecipe } from './runtime';

const inputConfig = {"name":"input"}

export const input = /* @__PURE__ */ createRecipe(inputConfig)