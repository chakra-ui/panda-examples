import { createSlotRecipe } from './runtime';

const switchRecipeConfig = {"name":"switchRecipe","className":"switch","slots":["root","thumb"],"defaultVariants":{"size":"default"},"variantMap":{"size":["default","sm"]}}

export const switchRecipe = /* @__PURE__ */ createSlotRecipe(switchRecipeConfig)