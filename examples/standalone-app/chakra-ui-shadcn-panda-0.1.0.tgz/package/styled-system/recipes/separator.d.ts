import type { ConditionalValue } from '../types/system';
import type { RecipeRuntimeFn, RecipeVariantMap } from '../types/recipe';

export type SeparatorVariant = {
  orientation?: "horizontal" | "vertical"
}

export type SeparatorVariantProps = {
  [K in keyof SeparatorVariant]?: ConditionalValue<SeparatorVariant[K]>
}

export type SeparatorVariantMap = RecipeVariantMap<SeparatorVariant>

export type SeparatorRecipe = RecipeRuntimeFn<SeparatorVariantProps, SeparatorVariantMap>

export declare const separator: SeparatorRecipe;