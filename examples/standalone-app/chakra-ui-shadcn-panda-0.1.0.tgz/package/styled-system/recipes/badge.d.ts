import type { ConditionalValue } from '../types/system';
import type { RecipeRuntimeFn, RecipeVariantMap } from '../types/recipe';

export type BadgeVariant = {
  variant?: "default" | "destructive" | "ghost" | "link" | "outline" | "secondary"
}

export type BadgeVariantProps = {
  [K in keyof BadgeVariant]?: ConditionalValue<BadgeVariant[K]>
}

export type BadgeVariantMap = RecipeVariantMap<BadgeVariant>

export type BadgeRecipe = RecipeRuntimeFn<BadgeVariantProps, BadgeVariantMap>

export declare const badge: BadgeRecipe;