import { createSlotRecipe } from './runtime';

const avatarConfig = {"name":"avatar","slots":["root","image","fallback"],"defaultVariants":{"size":"default"},"variantMap":{"size":["default","lg","sm"]}}

export const avatar = /* @__PURE__ */ createSlotRecipe(avatarConfig)