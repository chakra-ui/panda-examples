import { createSlotRecipe } from './runtime';

const cardConfig = {"name":"card","slots":["root","header","title","description","action","content","footer"]}

export const card = /* @__PURE__ */ createSlotRecipe(cardConfig)