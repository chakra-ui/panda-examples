import type { ConditionalValue } from '../types/system';
import type { SlotRecipeRuntimeFn, RecipeVariantMap } from '../types/recipe';

export type CardVariant = {}

export type CardVariantProps = {
  [K in keyof CardVariant]?: ConditionalValue<CardVariant[K]>
}

export type CardVariantMap = RecipeVariantMap<CardVariant>

export type CardSlot = "root" | "header" | "title" | "description" | "action" | "content" | "footer"

export type CardRecipe = SlotRecipeRuntimeFn<CardSlot, CardVariantProps, CardVariantMap>

export declare const card: CardRecipe;