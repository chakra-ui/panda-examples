import type { ConditionalValue } from '../types/system';
import type { RecipeRuntimeFn, RecipeVariantMap } from '../types/recipe';

export type SkeletonVariant = {}

export type SkeletonVariantProps = {
  [K in keyof SkeletonVariant]?: ConditionalValue<SkeletonVariant[K]>
}

export type SkeletonVariantMap = RecipeVariantMap<SkeletonVariant>

export type SkeletonRecipe = RecipeRuntimeFn<SkeletonVariantProps, SkeletonVariantMap>

export declare const skeleton: SkeletonRecipe;