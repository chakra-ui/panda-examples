import { createRecipe } from './runtime';

const badgeConfig = {"name":"badge","defaultVariants":{"variant":"default"},"variantMap":{"variant":["default","destructive","ghost","link","outline","secondary"]}}

export const badge = /* @__PURE__ */ createRecipe(badgeConfig)