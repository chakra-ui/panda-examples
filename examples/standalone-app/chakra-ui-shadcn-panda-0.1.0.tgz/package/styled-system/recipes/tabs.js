import { createSlotRecipe } from './runtime';

const tabsConfig = {"name":"tabs","slots":["root","list","trigger","content"]}

export const tabs = /* @__PURE__ */ createSlotRecipe(tabsConfig)