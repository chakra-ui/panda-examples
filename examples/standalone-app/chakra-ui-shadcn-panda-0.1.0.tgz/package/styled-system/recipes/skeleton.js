import { createRecipe } from './runtime';

const skeletonConfig = {"name":"skeleton"}

export const skeleton = /* @__PURE__ */ createRecipe(skeletonConfig)