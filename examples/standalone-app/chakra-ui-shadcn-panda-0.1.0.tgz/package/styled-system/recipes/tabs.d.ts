import type { ConditionalValue } from '../types/system';
import type { SlotRecipeRuntimeFn, RecipeVariantMap } from '../types/recipe';

export type TabsVariant = {}

export type TabsVariantProps = {
  [K in keyof TabsVariant]?: ConditionalValue<TabsVariant[K]>
}

export type TabsVariantMap = RecipeVariantMap<TabsVariant>

export type TabsSlot = "root" | "list" | "trigger" | "content"

export type TabsRecipe = SlotRecipeRuntimeFn<TabsSlot, TabsVariantProps, TabsVariantMap>

export declare const tabs: TabsRecipe;