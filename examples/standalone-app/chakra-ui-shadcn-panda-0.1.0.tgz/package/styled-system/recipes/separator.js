import { createRecipe } from './runtime';

const separatorConfig = {"name":"separator","defaultVariants":{"orientation":"horizontal"},"variantMap":{"orientation":["horizontal","vertical"]}}

export const separator = /* @__PURE__ */ createRecipe(separatorConfig)