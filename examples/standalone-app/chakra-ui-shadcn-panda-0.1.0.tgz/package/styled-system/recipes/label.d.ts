import type { ConditionalValue } from '../types/system';
import type { RecipeRuntimeFn, RecipeVariantMap } from '../types/recipe';

export type LabelVariant = {}

export type LabelVariantProps = {
  [K in keyof LabelVariant]?: ConditionalValue<LabelVariant[K]>
}

export type LabelVariantMap = RecipeVariantMap<LabelVariant>

export type LabelRecipe = RecipeRuntimeFn<LabelVariantProps, LabelVariantMap>

export declare const label: LabelRecipe;