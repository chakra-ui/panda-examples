import { createRecipe } from './runtime';

const buttonConfig = {"name":"button","className":"btn","defaultVariants":{"size":"default","variant":"default"},"variantMap":{"size":["default","icon","lg","sm"],"variant":["default","destructive","ghost","link","outline","secondary"]}}

export const button = /* @__PURE__ */ createRecipe(buttonConfig)